﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebAPI3.Models;

namespace WebAPI3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public TaskController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        [HttpPost]
        [Route("AddTask")]
         public Response AddTask(tblTask task)
         {
             Response response = new Response();
             SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("SNCon").ToString());

             Dal dal = new Dal();
             response = dal.AddTask(task, connection);

             return response;

        }
        [HttpGet]
        [Route("TaskList")]
        public Response TaskList()
        {
            Response response = new Response();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("SNCon").ToString());

            Dal dal = new Dal();
            response = dal.TaskList(connection);

            return response;

        }
        [HttpPut]
        [Route("UpdateTask")]
        public Response UpdateTask(tblTask task)
        {
            Response response = new Response();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("SNCon").ToString());

            Dal dal = new Dal();
            response = dal.UpdateTask(task, connection);

            return response;
        }
        [HttpDelete]
        [Route("DeleteTask/{taskId}")]
        public Response DeleteTask(int taskId)
        {
            Response response = new Response();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("SNCon").ToString());

            Dal dal = new Dal();
            response = dal.DeleteTask(taskId, connection);

            return response;
        }


    }
}
