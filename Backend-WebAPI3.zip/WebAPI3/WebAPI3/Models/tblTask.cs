﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;



namespace WebAPI3.Models
{
    public class tblTask
    {
        public int Id { get; set; }
        public string TName { get; set; }
        public string Asignto { get; set; }
        public string Status { get; set; }
        public int IsActive { get; set; }

    }
}
