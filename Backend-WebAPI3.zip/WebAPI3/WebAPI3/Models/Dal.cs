﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace WebAPI3.Models
{
    public class Dal
    {
        public Response Registration(Registration registration,SqlConnection connection)
        {
            Response response = new Response();
            SqlCommand cmd = new SqlCommand("INSERT INTO Registration(Name,Email,Password,PhoneNo,IsActive) VALUES ('"+registration.Name+ "','"+registration.Email + "','"+registration.Password+ "','"+registration.PhoneNo+ "',1)",connection);
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if(i > 0) {
                response.StatusCode = 200;
                response.StatusMessage = "registration Successfull";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "registration Failed";
            }

            return response;
        }

        public Response login(Registration registration,SqlConnection connection)
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Registration WHERE Email = '" + registration.Email+ "' AND Password ='"+registration.Password+"' ",connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response response = new Response();
            if(dt.Rows.Count > 0)
            {
             response.StatusCode=200;
                response.StatusMessage = "Login SuccessFull";
                Registration reg = new Registration();
                reg.Id =Convert.ToInt32(dt.Rows[0]["Id"]);
                reg.Name = Convert.ToString(dt.Rows[0]["Name"]);
                reg.Email = Convert.ToString(dt.Rows[0]["Email"]);
                reg.Password = Convert.ToString(dt.Rows[0]["Password"]);
                response.Registration = reg;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Login Faild";
                response.Registration = null;

            }
            return response;
        }

        public Response AddTask(tblTask task,SqlConnection connection)
        {
            Response response = new Response(); 
            SqlCommand cmd = new SqlCommand("INSERT INTO tblTask(TName,Asignto,Status,IsActive) VALUES('" + task.TName+ "','"+task.Asignto+ "','"+task.Status+"',1)", connection);
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0)
            {
                response.StatusCode = 200;
                response.StatusMessage = " Successfull";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = " Failed";
            }
            return response;
        }
        public Response TaskList(SqlConnection connection)
        {
            Response response = new Response();
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM tblTask ", connection);
            DataTable dt = new DataTable();
            da.Fill(dt);
            List<tblTask> lstTasks = new List<tblTask>();

            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    tblTask task = new tblTask();
                    task.Id = Convert.ToInt32(dt.Rows[i]["Id"]);
                    task.TName = Convert.ToString(dt.Rows[i]["TName"]);
                    task.Asignto = Convert.ToString(dt.Rows[i]["Asignto"]);
                    task.Status = Convert.ToString(dt.Rows[i]["Status"]);
                    task.IsActive = Convert.ToInt32(dt.Rows[i]["IsActive"]);

                    lstTasks.Add(task); // Add the task to the list
                }

                if (lstTasks.Count > 0)
                {
                    response.StatusCode = 200;
                    response.ListTask = lstTasks;
                    response.StatusMessage = "Data found";
                }
                else
                {
                    response.StatusCode = 100;
                    response.ListTask = null;
                    response.StatusMessage = "Data not found";
                }
            }

            return response;
        }
        public Response UpdateTask(tblTask task, SqlConnection connection)
        {
            Response response = new Response();

            using (SqlCommand cmd = new SqlCommand("UPDATE tblTask SET TName = @TName, Asignto = @Asignto, Status = @Status WHERE Id = @Id", connection))
            {
                cmd.Parameters.AddWithValue("@TName", task.TName);
                cmd.Parameters.AddWithValue("@Asignto", task.Asignto);
                cmd.Parameters.AddWithValue("@Status", task.Status);
                cmd.Parameters.AddWithValue("@Id", task.Id);

                try
                {
                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        response.StatusCode = 200;
                        response.StatusMessage = "Task updated successfully";
                    }
                    else
                    {
                        response.StatusCode = 100;
                        response.StatusMessage = "Task not found or update failed";
                    }
                }
                catch (Exception ex)
                {
                    response.StatusCode = 500; // Server error
                    response.StatusMessage = "Error: " + ex.Message;
                }
            }

            return response;
        }
        public Response DeleteTask(int taskId, SqlConnection connection)
        {
            Response response = new Response();

            using (SqlCommand cmd = new SqlCommand("UPDATE tblTask SET IsActive = 0 WHERE Id = @Id", connection))
            {
                cmd.Parameters.AddWithValue("@Id", taskId);

                try
                {
                    connection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        response.StatusCode = 200;
                        response.StatusMessage = "Task deleted successfully";
                    }
                    else
                    {
                        response.StatusCode = 100;
                        response.StatusMessage = "Task not found or delete failed";
                    }
                }
                catch (Exception ex)
                {
                    response.StatusCode = 500; // Server error
                    response.StatusMessage = "Error: " + ex.Message;
                }
            }

            return response;
        }


    }
}
