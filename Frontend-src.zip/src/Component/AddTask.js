import React, { Component } from 'react';
import axios from 'axios';
import { CorsOptions } from 'cors';
import { Link } from 'react-router-dom'; 
import { clear } from '@testing-library/user-event/dist/clear';

class AddTaskForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      taskName: '',
      assignTo: '',
      status: '',
    };
  }

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  handleAddTask = (e) => {
    e.preventDefault();

    const { taskName, assignTo, status } = this.state;
    const url ='http://localhost:5273/api/Task/AddTask';

    const data = {
      TName: taskName,
      Asignto: assignTo,
      Status: status,
    };

    axios.post(url,data)
      .then((result) => {
        const dt =result.data;
alert('Task added successfully');
        console.log('Task added successfully');
      })
      .catch((error) => {
        console.error('Failed to add the task');
      });
  }
  

  render() {
    const { taskName, assignTo, status } = this.state;
   
   
    return (
      <div>
        <h2>Add Task</h2>
        <form onSubmit={this.handleAddTask}>
          <div>
            <label>Task Name:</label>
            <input
              type="text"
              name="taskName"
              value={taskName}
              onChange={this.handleInputChange}
              required
            />
          </div>
          <div>
            <label>Assign To:</label>
            <input
              type="text"
              name="assignTo"
              value={assignTo}
              onChange={this.handleInputChange}
              required
            />
          </div>
          <div>
            <label>Status:</label>
            <input
              type="text"
              name="status"
              value={status}
              onChange={this.handleInputChange}
              required
            />
          </div>
          <button type="submit">Add Task</button>
        </form>
      </div>
    );
  }
}

export default AddTaskForm;
