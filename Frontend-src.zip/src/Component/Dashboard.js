import React, { Component } from 'react';
import { Link } from 'react-router-dom'; 
import axios from 'axios';

class TaskView extends Component {
  constructor(props) {
    super(props);

    this.state = {
      tasks: [], 
    };
  }

  componentDidMount() {
    this.fetchTasks();
  }

  fetchTasks() {
    fetch('http://localhost:5273/api/Task/TaskList') 
      .then(response => response.json())
      .then(data => {
        if (data.StatusCode === 200) {
          this.setState({ tasks: data.ListTask });
        }
      })
      .catch(error => console.error('Error fetching tasks:', error));
  }

  handleEditTask(taskId) {
    const editURL = `http://localhost:5273/edit/${taskId}`;
    window.open(editURL, '_blank');
    
  }

  handleDeleteTask(taskId, e) {
    e.preventDefault(); 
    const confirmed = window.confirm('Are you sure you want to delete this task?');
    if (confirmed) {
      const { taskName, assignTo, status } = this.state;
      const url = `http://localhost:5273/api/Task/DeleteTask/${taskId}`;
  
      const requestData = {
        TName: taskName,
        Asignto: assignTo,
        Status: status,
      };
  
      axios.post(url, requestData)
        .then((result) => {
          const dt = result.data;
          console.log('Task Deleted successfully');
        })
        .catch((error) => {
          console.error('Failed to Delete the task');
        });
    }
  }
  

  render() {
    const { tasks } = this.state;

    return (
      <div>
        <h1>Task List</h1>
        <table>
          <thead>
            <tr>
              <th>Task Name</th>
              <th>Assign To</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {tasks.map(task => (
              <tr key={task.Id}>
                <td>{task.TName}</td>
                <td>{task.Asignto}</td>
                <td>{task.Status}</td>
                <td>
                <Link to={`/edit/${task.Id}`}>Edit</Link>
                  <button onClick={() => this.handleDeleteTask(task.Id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default TaskView;
