import React, { Component } from 'react';
import axios from 'axios';

class EditTask extends Component {
  constructor(props) {
    super(props);

    this.state = {
      taskName: '',  
      assignTo: '',
      status: '',
    };
  }

  componentDidMount() {
    const { taskId } = this.props.match.params;


    fetch(`http://localhost:5273/api/Task/UpdateTask/${taskId}`)
      .then(response => response.json())
      .then(data => {
        this.setState({
          taskName: data.taskName,
          assignTo: data.assignTo,
          status: data.status,
        });
      })
      .catch(error => console.error('Error fetching task:', error));
  }

  handleUpdateTask = () => {
    const { taskId } = this.props.match.params;
    const { taskName, assignTo, status } = this.state;
  
    const updatedTask = {
      taskName,
      assignTo,
      status,
    };
  
    const url = `http://localhost:5273/api/Task/UpdateTask/${taskId}`;
  
    axios.put(url, updatedTask) 
      .then((result) => {
        const dt = result.data;
        console.log('Task Updated successfully');
      })
      .catch((error) => {
        console.error('Failed to update the task');
      });
  }
  

  render() {
    return (
      <div>
        <h1>Edit Task</h1>
        <div>
          <label>Task Name:</label>
          <input
            type="text"
            value={this.state.taskName}
            onChange={(e) => this.setState({ taskName: e.target.value })}
          />
        </div>
        <div>
          <label>Assignee:</label>
          <input
            type="text"
            value={this.state.assignTo}
            onChange={(e) => this.setState({ assignTo: e.target.value })}
          />
        </div>
        <div>
          <label>Status:</label>
          <input
            type="text"
            value={this.state.status}
            onChange={(e) => this.setState({ status: e.target.value })}
          />
        </div>
        <button onClick={this.handleUpdateTask}>Update Task</button>
      </div>
    );
  }
}

export default EditTask;
