import React, { Component } from 'react';
import { Link, useHistory } from 'react-router-dom'; 
import axios from 'axios';
import './LoginForm.css';

class LoginForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: '',
      password: ''
    };
    
  }

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { email, password } = this.state;
    console.log(`Email: ${email}, Password: ${password}`);
    const url ='http://localhost:5273/api/Registration/Login';

    const data = {
      Email: email,
      Password: password
    };

    axios.post(url, data)    
    .then((result) => {
        const loginResult = result.data;
        if (result.success) {
          this.props.history.push('/TaskComponent'); 
          console.log(`Login Success`);

        } else {

          console.log(`Eror`);
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }
 
  render() {
    const { email, password } = this.state;

    return (
      <div className="login-form">
        <h2>Login Form</h2>
        <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={this.handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={this.handleInputChange}
              required
            />
          </div>

          <button type="submit">Login</button>

          <p>Don't have an account? <Link to="/registration">Register</Link></p>
        </form>
      </div>
    );
  }
}

export default  LoginForm;
