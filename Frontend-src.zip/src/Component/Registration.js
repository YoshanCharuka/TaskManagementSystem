import React, { Component } from 'react';
import axios from 'axios';
import './RegistrationForm.css'; // Import your CSS file for styling
import { CorsOptions } from 'cors';
import { Link } from 'react-router-dom'; // Import Link from React Router
class RegistrationForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: '',
      email: '',
      Mobile:'',
      password: ''
    };
  }

  handleInputChange = (e) => {
    const { name, value } = e.target;
    this.setState({ [name]: value });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const { name, email, password ,Mobile} = this.state;
    console.log(`Name: ${name}, Email: ${email},Mobile: ${Mobile}, Password: ${password}`);
    const url ='http://localhost:5273/api/Registration/Registration';

    const data = {
      Name: name,
      Email:email,
      Password:password,
      PhoneNo:Mobile
    }
    axios.post(url,data)
    .then((result)=>{
      const dt =result.data;
    })
    .catch((error)=>{
      console.log(error);
    })
  }

  render() {
    const { name, email, password ,Mobile} = this.state;

    return (
      <div className="registration-form">
        <h2>Registration Form</h2>
        <form onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label htmlFor="name">Name:</label>
            <input
              type="text"
              id="name"
              name="name"
              value={name}
              onChange={this.handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              id="email"
              name="email"
              value={email}
              onChange={this.handleInputChange}
              required
            />
          </div> 
            <div className="form-group">
            <label htmlFor="Mobile">Mobile:</label>
            <input
              type="text"
              id="Mobile"
              name="Mobile"
              value={Mobile}
              onChange={this.handleInputChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={this.handleInputChange}
              required
            />
          </div>

          <button type="submit">Register</button>
          <p> <Link to="/LoginForm">Back to Login Page</Link></p>

        </form>
      </div>
    );
  }
}

export default RegistrationForm;
