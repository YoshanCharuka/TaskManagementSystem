import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'; // Update the import
import LoginForm from './Component/LoginForm';
import RegistrationForm from './Component/Registration';
import AddTask from './Component/AddTask';
import Dashboard from './Component/Dashboard';
import EditTask from './Component/EditTask';


function App() {
  return (
    <Router>
      <div className="App">
        <Routes> {/* Replace Switch with Routes */}
          <Route path="/" element={<LoginForm />} />
          <Route path="/registration" element={<RegistrationForm />} />
          <Route path="/LoginForm" element={<LoginForm/>} />
          <Route path="/AddTask" element={<AddTask/>} />
          <Route path="/Dashboard" element={<Dashboard/>} />
          <Route path="/EditTask" element={<EditTask/>} />

        </Routes>
      </div>
    </Router>
  );
}

export default App;
